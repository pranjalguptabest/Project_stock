import { Injectable } from '@angular/core';
import { HttpClient, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs';
import { IPOdetail } from 'src/entity/IPOdetail';

type EntityResponseType = HttpResponse<IPOdetail[]>;

@Injectable({
  providedIn: 'root'
})
export class IpoDetailService {

  constructor(private http:HttpClient) { }

    getAllCompanyDetails():Observable<EntityResponseType>{
      return this.http.get<IPOdetail[]>("http://localhost:8093/iPOdetails", {observe: 'response'});
    }

    saveCompanyDetails(IPOdetail:IPOdetail){
      return this.http.post<IPOdetail>("http://localhost:8093/iPOdetail", IPOdetail, {observe: 'response'});
    }
}

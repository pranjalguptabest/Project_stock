import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-sector',
  templateUrl: './compare-sector.component.html',
  styleUrls: ['./compare-sector.component.css']
})
export class CompareSectorComponent implements OnInit {

  public barChartOptions = {
    scaleShowVerticalsLines: false,
    responsive: true
  
  };
  public barChartLabels = ['SERVICE','IT','AUTONOBILE','FINANCE','MEDICAL','REAL-ESTATE','AGRICULTURE'];
  public barChartType = 'bar';
  public barChartLegend = 'true';
  public barChartData = [
    {data: [2000, 7300, 4500, 5400, 6200, 3500, 4000], label: 'Sector'}
  ]

  constructor() { }

  ngOnInit(): void {
  }

}

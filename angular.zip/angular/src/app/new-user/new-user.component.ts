import { Component, OnInit } from '@angular/core';
import { NewUserService } from './new-user.service';
import { Router } from '@angular/router';
import { FormGroup, FormControl } from '@angular/forms';
import { UserDatabaseModel } from 'src/entity/UserDatabase';

@Component({
  selector: 'app-new-user',
  templateUrl: './new-user.component.html',
  styleUrls: ['./new-user.component.css']
})
export class NewUserComponent implements OnInit {
  myForm2: FormGroup;
  userDetails2: UserDatabaseModel[];

  constructor(private service:NewUserService, private router: Router) { }

  ngOnInit(): void {
    this.myForm2= new FormGroup({
      name: new FormControl(''),
      mob: new FormControl(''),
      eid: new FormControl(''),
      pwd: new FormControl(''),
    });
    this.service.getAllUserDatabase().subscribe(data =>{
      this.userDetails2=data.body;
      console.log(data.body)
    });
  }
  onSubmit2(form: FormGroup)
  {
    var x= (form.value.name + form.value.pwd);
    let userDetails2: UserDatabaseModel={
      id:x,
      username:form.value.name,
      password: form.value.pwd,
      usertype:'user',
      email: form.value.eid,
      mobile_number: form.value.mob,
      confirmation:'confirmed'
    }

    this.service.saveUserDatabase(userDetails2).subscribe(data =>{
      console.log(data.body);
    });
    this.router.navigate(['/home']);
  }

}

import { Component, OnInit } from '@angular/core';
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { FormGroup, FormControl } from '@angular/forms';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-create-company',
  templateUrl: './create-company.component.html',
  styleUrls: ['./create-company.component.css']
})
export class CreateCompanyComponent implements OnInit {

  userDetails:CompanyDetailsModel[];
  myForm3: FormGroup;
  constructor(private service:CompanyDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body)
 });

 {
   this.myForm3 = new FormGroup({
    companyname: new FormControl(''),
    ceoname: new FormControl(''),
    bod: new FormControl(''),
    turnover: new FormControl(''),
    description: new FormControl(''),
    sname: new FormControl(''),
    sector: new FormControl(''),
    scode: new FormControl(''),

   });

 }
  }
 onSubmit3(form: FormGroup){
   let CompanyDetails:CompanyDetailsModel={
    company_name : form.value.companyname,
    ceo : form.value.ceoname,
    board_of_directors : form.value.bod,
    turnover : form.value.turnover,
    brief_about_companies : form.value.description,
    listed_in_stock_exchange : form.value.sname,
    sector : form.value.sector,
    stock_code_in_each_stock_exchange : form.value.scode,
   };

   this.service.saveCompanyDetails(CompanyDetails).subscribe(data =>{
     console.log(data.body);
   })
   this.router.navigate(['/manageCompany'])
 }
 Refresh(){
   window.location.reload();
 }
}

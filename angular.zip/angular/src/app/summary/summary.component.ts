import { Component, OnInit } from '@angular/core';
import { ExcelModel } from 'src/entity/Excel';
import { ImportDataService } from '../import-data/import-data.service';
import { Router } from '@angular/router';
import { ExcelResponseModel } from 'src/entity/ExcelResponse';

@Component({
  selector: 'app-summary',
  templateUrl: './summary.component.html',
  styleUrls: ['./summary.component.css']
})
export class SummaryComponent implements OnInit {
  excelDetails: ExcelModel[];

  constructor(private service:ImportDataService,private router: Router) { }
  //excelsummary: ExcelResponseModel[];
  excelSumary1:ExcelResponseModel;
  ss: any;

  ngOnInit(): void {
    
    this.service.getAllDetails().subscribe(data => {
    this.excelDetails = data.body;
    console.log(data.body) 
  });


  this.service.getAllDetails1().subscribe(data => {
    this.excelSumary1 = data.body;
    console.log(data.body);

  });

  
}

}

import { CompFilterPipe } from './comp-filter.pipe';

describe('CompFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new CompFilterPipe();
    expect(pipe).toBeTruthy();
  });
});

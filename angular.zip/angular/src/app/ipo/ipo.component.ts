import { Component, OnInit } from '@angular/core';
import { IPOdetail } from 'src/entity/IPOdetail';
import { IpoDetailService } from 'src/service/ipo-detail.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-ipo',
  templateUrl: './ipo.component.html',
  styleUrls: ['./ipo.component.css']
})
export class IpoComponent implements OnInit {
  userDetails: IPOdetail[];

  constructor(private service: IpoDetailService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data =>{
      this.userDetails = data.body;
      console.log(data.body)
    });
  }

}

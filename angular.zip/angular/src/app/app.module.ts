import { BrowserModule } from '@angular/platform-browser';


import { ReactiveFormsModule, FormsModule } from '@angular/forms';



import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserComponent } from './user/user.component';
import { AdminComponent } from './admin/admin.component';
import { HomeComponent } from './home/home.component';
import { ImportDataComponent } from './import-data/import-data.component';
import { ManageCompanyComponent } from './manage-company/manage-company.component';
import { ManageExchangeComponent } from './manage-exchange/manage-exchange.component';
import { UpdateIPOComponent } from './update-ipo/update-ipo.component';
import { CreateCompanyComponent } from './create-company/create-company.component';
import { RouterModule,Routes } from '@angular/router';
import { IpoComponent } from './ipo/ipo.component';
import { CompareCompanyComponent } from './compare-company/compare-company.component';
import { CompareSectorComponent } from './compare-sector/compare-sector.component';

import { HttpClient, HttpClientModule } from '@angular/common/http';
import {UserDatabaseService} from 'src/service/user-database.service';
import {CompanyDetailsService} from 'src/service/company-details.service';
import { NewUserComponent } from './new-user/new-user.component';
import { from } from 'rxjs';
import { CompFilterPipe } from './comp-filter.pipe';
import { ViewCompanyComponent } from './view-company/view-company.component';
import { EditDetailsComponent } from './edit-details/edit-details.component';
import { NewUserService } from './new-user/new-user.service';
import { ImportDataService } from './import-data/import-data.service';
import { BarChartComponent } from './bar-chart/bar-chart.component';
import { NgModule } from '@angular/core';
import { ChartsModule } from 'ng2-charts';
import { IpoDetailService } from 'src/service/ipo-detail.service';
import { ManageExchangeService } from 'src/service/manage-exchange.service';
import { SummaryComponent } from './summary/summary.component';

const routes:Routes=[
  {path:'' , redirectTo:'home', pathMatch:'full'},
  {path:'home' , component:HomeComponent},
  {path:'createCompany' , component:CreateCompanyComponent},
  {path:'manageCompany' , component:ManageCompanyComponent},
  {path:'manageExchange' , component:ManageExchangeComponent},
  {path:'updateIPO' , component:UpdateIPOComponent},
  {path:'importData' , component:ImportDataComponent},
  {path:'admin' , component:AdminComponent},
  {path:'user' , component:UserComponent},
  {path:'ipo' , component:IpoComponent},
  {path:'compareCompany' , component:CompareCompanyComponent},
  {path:'compareSector' , component:CompareSectorComponent},
  {path: 'newUser' , component:NewUserComponent},
  {path: 'viewCompany', component:ViewCompanyComponent},
  {path: 'editDetails', component:EditDetailsComponent},
  {path: 'barChart', component:BarChartComponent},
  {path: 'summary', component:SummaryComponent},

];
@NgModule({
  declarations: [
    AppComponent,
    UserComponent,
    AdminComponent,
    HomeComponent,
    ImportDataComponent,
    ManageCompanyComponent,
    ManageExchangeComponent,
    UpdateIPOComponent,
    CreateCompanyComponent,
    IpoComponent,
    CompareCompanyComponent,
    CompareSectorComponent,
    NewUserComponent,
    CompFilterPipe,
    ViewCompanyComponent,
    EditDetailsComponent,
    BarChartComponent,
    SummaryComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    ReactiveFormsModule,
    RouterModule.forRoot(routes),
    FormsModule,
    ChartsModule
  ],
  providers: [
    UserDatabaseService, 
    CompanyDetailsService, 
    NewUserService, 
    ImportDataService, 
    IpoDetailService, 
    ManageExchangeService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }

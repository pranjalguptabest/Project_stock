import { Component, OnInit, EventEmitter} from "@angular/core";
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-manage-company',
  templateUrl: './manage-company.component.html',
  styleUrls: ['./manage-company.component.css']
})
export class ManageCompanyComponent implements OnInit {
  userDetails:CompanyDetailsModel[];
  constructor(private service:CompanyDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body)
 });

  }
  Submit2(comp)
  {
    window.localStorage.setItem('item2',JSON.stringify(comp));
    this.router.navigate(['/editDetails']);
  }
  Submit3(comp)
  {
    window.localStorage.removeItem(JSON.stringify(comp));
    this.router.navigate(['/manageCompany']);
  }
}

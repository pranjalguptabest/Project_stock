import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { IPOdetail } from 'src/entity/IPOdetail';
import { IpoDetailService } from 'src/service/ipo-detail.service';

@Component({
  selector: 'app-update-ipo',
  templateUrl: './update-ipo.component.html',
  styleUrls: ['./update-ipo.component.css']
})
export class UpdateIPOComponent implements OnInit {
  userDetails: IPOdetail[];

  constructor(private service: IpoDetailService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data =>{
      this.userDetails = data.body;
      console.log(data.body)
    });
  }

}

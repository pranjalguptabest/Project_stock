import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ManageExchange } from 'src/entity/ManageExchange';
import { ManageExchangeService } from 'src/service/manage-exchange.service';

@Component({
  selector: 'app-manage-exchange',
  templateUrl: './manage-exchange.component.html',
  styleUrls: ['./manage-exchange.component.css']
})
export class ManageExchangeComponent implements OnInit {
  userDetails: ManageExchange[];

  constructor(private service: ManageExchangeService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data =>{
      this.userDetails = data.body;
      console.log(data.body)
    });
  }

  Submit2(com)
  {
    window.localStorage.setItem('item2',JSON.stringify(com));
    this.router.navigate(['/manageExchange']);
  }

}

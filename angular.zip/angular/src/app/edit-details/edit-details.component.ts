import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { FormGroup, FormControl } from '@angular/forms';

@Component({
  selector: 'app-edit-details',
  templateUrl: './edit-details.component.html',
  styleUrls: ['./edit-details.component.css']
})
export class EditDetailsComponent implements OnInit {
  userDetails:CompanyDetailsModel[];
  bbb:any;
  myForm6: FormGroup;

  constructor(private router:Router, private service:CompanyDetailsService) { }

  ngOnInit(): void {
    let aaa:string= window.localStorage.getItem('item2');
    this.bbb= JSON.parse(aaa);
    {
      this.myForm6= new FormGroup({
        ceo: new FormControl(''),
        bod: new FormControl(''),
        turnover: new FormControl(''),
        desc: new FormControl(''),
        sname: new FormControl(''),
        sector: new FormControl(''),
        scode: new FormControl(''),
      });
    }
  }

  onSubmit6(form: FormGroup)
  {
    let userDetails:CompanyDetailsModel=this.bbb;

    let a: string = form.value.ceo;
    let b: string = form.value.bod;
    let c: string = form.value.turnover;
    let d: string = form.value.desc;
    let e: string = form.value.sname;
    let f: string = form.value.sector;
    let g: string = form.value.scode;

    if(form.value.ceo==0){a=userDetails.ceo}
    if(form.value.bod==0){b=userDetails.board_of_directors}
    if(form.value.turnover==0){c=userDetails.turnover}
    if(form.value.desc==0){d=userDetails.brief_about_companies}
    if(form.value.sname==0){e=userDetails.listed_in_stock_exchange}
    if(form.value.sector==0){f=userDetails.sector}
    if(form.value.scode==0){g=userDetails.stock_code_in_each_stock_exchange}

    let userDetails2:CompanyDetailsModel={
      company_name: userDetails.company_name,
      ceo                               :a,
      board_of_directors                :b,
      turnover                          :c,
      brief_about_companies             :d,
      listed_in_stock_exchange          :e,
      sector                            :f,
      stock_code_in_each_stock_exchange :g,
    }
    this.service.saveCompanyDetails(userDetails2).subscribe(data =>{
      console.log(data.body);
    });
    window.localStorage.removeItem('item2');
    this.router.navigate(['/manageCompany']);
  }

}

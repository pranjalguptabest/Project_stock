import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-compare-company',
  templateUrl: './compare-company.component.html',
  styleUrls: ['./compare-company.component.css']
})
export class CompareCompanyComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}

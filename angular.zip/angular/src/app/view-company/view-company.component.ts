import { Component, OnInit } from '@angular/core';
import { CompanyDetailsModel } from 'src/entity/CompanyDetails';
import { CompanyDetailsService } from 'src/service/company-details.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-view-company',
  templateUrl: './view-company.component.html',
  styleUrls: ['./view-company.component.css']
})
export class ViewCompanyComponent implements OnInit {
  userDetails:CompanyDetailsModel[];
  company: string;
  constructor(private service:CompanyDetailsService, private router: Router) { }

  ngOnInit(): void {
    this.service.getAllCompanyDetails().subscribe(data => {
      this.userDetails = data.body;
      console.log(data.body)
 });

  }

  Search(){
    if(this.company !="")
    {
      this.userDetails= this.userDetails.filter(a=>
        {return a.company_name.toLowerCase().match(this.company.toLocaleLowerCase())})
    }
    else if(this.company =="")
    {
      this.ngOnInit();
    }
    
  }
}

export interface IPOdetail{
    id:String;
    company_name:String;
    price_per_share:String;
    total_no_of_shares:String;
}
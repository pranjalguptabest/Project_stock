export interface UserDatabaseModel{
    id : string;
	username : string;
	password :string;
	usertype : string;
	email : string;
	mobile_number : string;
	confirmation : string;
}
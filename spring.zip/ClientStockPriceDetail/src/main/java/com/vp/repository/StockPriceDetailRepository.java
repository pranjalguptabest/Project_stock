package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.StockPriceDetail;

public interface StockPriceDetailRepository extends CrudRepository<StockPriceDetail, Long>{

}
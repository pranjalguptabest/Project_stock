package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.IPOdetail;

public interface IPOdetailRepository extends CrudRepository<IPOdetail, Long>  {

}

package com.vp.repository;

import org.springframework.data.repository.CrudRepository;

import com.vp.model.ManageExchange;

public interface ManageExchangeRepository extends CrudRepository<ManageExchange, Long> {

}

package com.vp.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "ipo_planned")

public class IPOdetail {
	@Id
	private String id;
	private String company_name;
	private String price_per_share;
	private String total_no_of_shares;
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getCompany_name() {
		return company_name;
	}
	public void setCompany_name(String company_name) {
		this.company_name = company_name;
	}
	public String getPrice_per_share() {
		return price_per_share;
	}
	public void setPrice_per_share(String price_per_share) {
		this.price_per_share = price_per_share;
	}
	public String getTotal_no_of_shares() {
		return total_no_of_shares;
	}
	public void setTotal_no_of_shares(String total_no_of_shares) {
		this.total_no_of_shares = total_no_of_shares;
	}
	public IPOdetail(String id, String company_name, String price_per_share, String total_no_of_shares) {
		super();
		this.id = id;
		this.company_name = company_name;
		this.price_per_share = price_per_share;
		this.total_no_of_shares = total_no_of_shares;
	}
	public IPOdetail() {
		super();
		// TODO Auto-generated constructor stub
	}
	@Override
	public String toString() {
		return "IPOdetail [id=" + id + ", company_name=" + company_name + ", price_per_share=" + price_per_share
				+ ", total_no_of_shares=" + total_no_of_shares + "]";
	}

}

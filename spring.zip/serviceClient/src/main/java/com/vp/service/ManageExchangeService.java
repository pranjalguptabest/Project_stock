package com.vp.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.vp.model.ManageExchange;
import com.vp.repository.ManageExchangeRepository;

@Service
@Transactional

public class ManageExchangeService {
	@Autowired
	ManageExchangeRepository manageExchangeRepository;
	
	public List<ManageExchange> getAllManageExchange(){
		return  (List<ManageExchange>) manageExchangeRepository.findAll();
	}
	
	public void saveManageExchange(ManageExchange manageExchange) {
		manageExchangeRepository.save(manageExchange);
	}

}
